﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
            @"Server=ZEVS-PC\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}