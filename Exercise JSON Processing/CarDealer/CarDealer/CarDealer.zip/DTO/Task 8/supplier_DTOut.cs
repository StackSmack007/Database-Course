﻿namespace CarDealer.DTO.Task_8
{
    public class supplier_DTOut
    {
        public int Id { get; set; }
 
        public string Name { get; set; }

        public int PartsCount { get; set; }
    }
}