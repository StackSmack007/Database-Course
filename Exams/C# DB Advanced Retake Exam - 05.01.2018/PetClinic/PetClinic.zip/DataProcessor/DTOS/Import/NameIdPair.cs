﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PetClinic.DataProcessor.DTOS.Import
{
  public  class NameIdPair
    {
        public string Name { get; set; }
        public int Id { get; set; }
    }
}
