﻿namespace CarDealer.DTO
{
    public  class partCar_in_DTO
    {
        public int PartId { get; set; }
    
        public int CarId { get; set; }

    }
}
