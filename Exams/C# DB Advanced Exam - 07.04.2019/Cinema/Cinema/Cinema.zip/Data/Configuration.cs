﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=ZEVS-PC\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
