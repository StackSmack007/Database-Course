﻿namespace CarDealer.DTO.Task_6
{
    using System;
    public class customer_DTO_out
    {
        public string Name { get; set; }

        public string BirthDate { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}