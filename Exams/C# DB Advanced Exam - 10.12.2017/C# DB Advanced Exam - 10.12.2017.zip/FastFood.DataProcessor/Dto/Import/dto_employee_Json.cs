﻿namespace FastFood.DataProcessor.Dto.Import
{
    public  class dto_employee_Json
    {
        public string Name { get; set; }
        public string Age { get; set; }
        public string Position    { get; set; }
    }
}