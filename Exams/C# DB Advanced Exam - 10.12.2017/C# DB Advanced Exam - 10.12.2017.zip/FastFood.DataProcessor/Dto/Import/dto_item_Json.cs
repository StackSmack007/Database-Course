﻿namespace FastFood.DataProcessor.Dto.Import
{
    public class dto_item_Json
    {
        public dto_item_Json()
        { }
        public string Name { get; set; }
        public string Price { get; set; }
        public string Category { get; set; }
    }
}