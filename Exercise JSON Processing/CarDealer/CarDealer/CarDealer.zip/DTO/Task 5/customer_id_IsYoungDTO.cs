﻿namespace CarDealer.DTO.Task_5
{
    public class customer_id_isYoungDTO
    {
        public int Id { get; set; }

        public bool IsYoungDriver { get; set; }
    }
}